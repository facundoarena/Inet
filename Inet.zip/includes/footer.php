<link rel="stylesheet" href="../estilos/detalles.css">
<footer class="foot">
    <img src="../public/img/descarga.png">
</footer>